My code can by run in main.py

I use a few packages. These Packages are 

sklearn
numpy
pandas
matplotlib

All of these libraries can be downloaded via the commmand tool pip

The code can be run with 

$ python3 main.py

Do note that all the csv files must be in the same directory as the code for the program to work

$ python3 main.py -v 

gives a verbose printing of what the code is doing and 

$ python3 main.py -k

Will give the kmean cluster diagram
