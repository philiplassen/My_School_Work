Python3 and numpy are the only things that need to be installed. The code can be run by doing the following.


python3 problem4.py 
