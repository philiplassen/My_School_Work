My code is in the file main.py

It runs with python3. It is only dependent on three libraries which are

sklean
numpy
matplotlib

They can be downloaded with the following command

pip3 install sklean
pip3 install matplotlib
pip3 install numpy


The code can be run with the following command.

python3 main.py
