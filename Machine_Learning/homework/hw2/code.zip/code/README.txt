My code is in two files

problem1.py
problem5.py

They run with python3, and are only dependent on the libraries random, numpy and mathplotlib.

numpy and mathplotlib can be installed with the following command

pip3 install numpy
pip3 install matplotlib

The code can be run with the following

python3 problem1.py

And problem5.py can just be imported to use its functions with an import statement of 

import problem5.py  
